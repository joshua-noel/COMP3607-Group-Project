// 816031467
import java.util.Random;

public class Passenger
{
   // Attributes
    String passportNumber;
    String flightNo;
    private String firstName;
    private String lastName;
    private int numLuggage;
    private char cabinClass;
  
    // umm can the values passing in be the same name as the 
    //values being assigned
    public Passenger (String passportNumber,String firstName, String lastName,String flightNo){
        this.passportNumber= passportNumber;
        this.firstName = firstName;
        this.lastName= lastName;
        this.flightNo = flightNo; 
        getRandomLuggageAmount();
        assignRandomCabinClass();
        
      //  System.out.println (assignRandomCabinClass);
    }

     
     
    // Accessors 'Accessors are required for all attributes'
    public String getPassportNumber(){
        return passportNumber;
    }
    
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public String getFlightNo(){
        return flightNo;
    }
    
    public int getNumLuggage(){
        return numLuggage;
    }
    
    public char getCabinClass(){
        return cabinClass;
    }
    
      // public static void  assignRandomCabinClass() //testing purposes
     protected void  assignRandomCabinClass(){
         String [] cabinClass = { "F", "B", "P", "E"};
         Random rcc = new Random();
         this.cabinClass = cabinClass[rcc.nextInt(4)].charAt(0);
        // System.out.println (cabinClass[rcc.nextInt(4)]);
     }
     
     //public static void getRandomLuggageAmount() // testing purposes
     protected void getRandomLuggageAmount(){

        Random numLuggage = new Random();
        int rl = numLuggage.nextInt(10);
        this.numLuggage = rl;
        // System.out.println (rl);
     }
    
 //public static void  signRandomCabinClass(){ 
    public String toString(){
       // String fistLetter = getFirstName().substring(0,1);
        String details = " PP NO. " + getPassportNumber(); details+= " \t NUMLUGGAGE: " +numLuggage; 
        details+= " \t CLASS " +cabinClass; details+= " \t NAME " +getFirstName() + " "+ getLastName();
        return details;
    }
    
 
}
