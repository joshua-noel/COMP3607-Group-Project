// 816031467
import java.util.ArrayList;
import java.util.List;

public class LuggageManifest{
    ArrayList<LuggageSlip> slips;
    private Passenger p;
    private Flight f;
    
    public LuggageManifest(){
        slips = new ArrayList<LuggageSlip>();
    }

   // public String addLuggage (Passenger p, String f) { // amma just chhange this to a String
     public String addLuggage (Passenger p, Flight f) {
        int pieces = p.getNumLuggage();
        char cabinClassType = p.getCabinClass();
        int allowedLug = f.getAllowedLuggage(cabinClassType);
        double excessLCost = getExcessLuggageCost( pieces, allowedLug);

        for (int i = 0; i < pieces; i++) {
        LuggageSlip slip = new LuggageSlip(p, f, String.format("%.02f", excessLCost));
        this.slips.add(slip);
        }
        if (excessLCost > 0){
            return "Piece added: "+ "(" + pieces + ")"+ "Excess Cost: " + excessLCost;
        }
        else
        return "No Luggage to add";
        }
    
  
    public double getExcessLuggageCost( int numPieces, int numAllowedPieces){
        if (numPieces > numAllowedPieces) {
            int extraLuggage = numPieces - numAllowedPieces;
            double extraLuggageCost = extraLuggage * 35;
            return extraLuggageCost;
        }
        else {
            return 0;     
        }
    }
   
  public String getExcessLuggageCostByPassenger(String passportNumber) {
   double cost = 0;
   String finalCost= null;
    for (LuggageSlip slip : slips) {
        if (slip.getOwner().getPassportNumber().equals(passportNumber)) {
            int pieces = slip.getOwner().getNumLuggage();
            char cabinClassType = slip.getOwner().getCabinClass();
             int allowedLug = f.getAllowedLuggage(cabinClassType);
            double excessLCost = getExcessLuggageCost( pieces, allowedLug);
            cost = cost + getExcessLuggageCost(pieces,allowedLug );
            if (cost > 0) {
            finalCost = "Cost: " + cost;
            } else {
            finalCost = "No Cost";
            
        }
    }
    }
    return finalCost;
}

   
    public String toString(){
        StringBuilder concatination = new StringBuilder();
        for (LuggageSlip slip : slips) {
            concatination.append(slip.toString() + "\n");
        }
        return concatination.toString();
    }

}

