// 816031467
import java.io.File; // creates  a file obj that points to a file object
import java.util.Scanner; // to get input
//import java.util.StringTokenizer; // reads all string witout looking for white spaces
import java.io.FileReader;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;


public class LuggageManagementSystem {
    

    public static void main(String[] args) {
        //CLASS TESTING PURPOSES
        try {
            File dataFile = new File("PassengerList.txt");
            Scanner scanner = new Scanner(dataFile);
            String passengerData = " ";
            while(scanner.hasNextLine()) {
                passengerData = scanner.nextLine();
                String[] passengerInput = passengerData.split(",");
                Passenger p = new Passenger(passengerInput[0], passengerInput[1], passengerInput[2], passengerInput[3]);
                p.assignRandomCabinClass();
                p.getRandomLuggageAmount();
                System.out.println(p.toString());
            }
        } catch (Exception e) {
            System.out.println("Error File do not exist: ");
        }
        
        
    }
    
     public static void main2(String[] args) {
    List<Flight> flights = new ArrayList<>();

    try {
        File dataFile2 = new File("FlightList.txt");
        Scanner scanner = new Scanner(dataFile2);
        String flightData = " ";
      while(scanner.hasNextLine()) {
        flightData = scanner.nextLine();
        String[] values = flightData.split(",");
        String flightNo = values[0];
        String destination = values[1];
        String origin = values[2];
        int year = Integer.parseInt(values[3].split("-")[0]);
        int month = Integer.parseInt(values[3].split("-")[1]);
        int day = Integer.parseInt(values[3].split("-")[2]);
        int hour = Integer.parseInt(values[3].split("-")[3]);
        int minutes = Integer.parseInt(values[3].split("-")[4]);
        LocalDateTime flightDate = LocalDateTime.of(year, month, day, hour, minutes);
      //  LocalDateTime flightDate = LocalDateTime.of(2323,12,10,00,00); // hardcoded for testing purposes

        Flight flight = new Flight(flightNo, destination, origin, flightDate);
        flights.add(flight);
      }
    } catch (Exception e) {
      System.out.println("Error File do not exist: ");
    }

    for (Flight flight : flights) {
      System.out.println(flight.toString());
    }
    
  
  }
  
    
      public static void main3(String[] args) { //You are required to create Flights and passengers from file
       // sample hardcode from assignment 
    //    LocalDateTime d= LocalDateTime.of(2023,1,23,16, 88, 80);
        
        LocalDateTime d = LocalDateTime.of(2323,12,10,00,00);
        Flight yyz = new Flight("BW600", "POS", "YYz", d);
        System.out.println(yyz);
        Passenger p;
        String[] pps = {"TA898789", "BA321963", "LA400000"};
        String[] firstNames = {"Joe", "Lou", "Sid"};
        String[] lastNames = {"Bean", "Deer", "Hart"};
        for (int i = 0; i<3; i++){
        p = new Passenger (pps[i], firstNames[i], lastNames[1], "BW600"); 
        System.out.println(p);
        System.out.println(yyz.checkInLuggage(p));
 
        }
        
    System.out.println(yyz.printLuggageManifest());
    }
   
    
}
 
