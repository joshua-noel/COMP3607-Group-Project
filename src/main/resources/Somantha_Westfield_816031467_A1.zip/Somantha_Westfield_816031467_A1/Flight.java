// 816031467
import java.time.LocalDateTime;

public class Flight
{
  String flightNo;
  String destination;
  String origin;
  LocalDateTime flightDate;
  LuggageManifest  manifest;
  
  public Flight (String flightNo, String destination, String origin, LocalDateTime flightDate) {
    this.flightNo = flightNo;
    this.destination = destination;
    this.origin = origin;
    this.flightDate = flightDate;   
    }
    
  
    public String getFightNo(){
        return flightNo;
    }
    
    public String getDestination(){
        return destination;
    }
    
    public String getOrigin(){
        return origin;
    }
    
    public LocalDateTime getFlightDate(){
        return flightDate;
    }
    
    public LuggageManifest geMmanifest(){
        return manifest;
    }
    
   
  public String checkInLuggage(Passenger p){
  if(this.flightNo.equals(p.flightNo)){
    manifest = new LuggageManifest();
    manifest.addLuggage(p, this);
    return "Valid" + manifest.addLuggage(p, this);
  }
  else {
    return "Invalid flight" +manifest.addLuggage(p, this);
  }
}

  public String printLuggageManifest() {
  if (manifest == null) {
    manifest = new LuggageManifest();
  }
  return manifest.toString();
}

  public int getAllowedLuggage( char cabinClass){
        if (cabinClass=='F')
        {
            return 3;            
        }
        else if (cabinClass == 'B')
        {
            return 2;
        }
        else if (cabinClass == 'P')
        {
            return 1;
        }
        
        else if(cabinClass == 'E')
        {
            return 0;
        } 
        return -1;
    }

    
 public String toString(){
     String details = getFightNo() + "\t DESTINATION" + getDestination()+ "\t ORIGIN: " + getOrigin() + "\t" + getFlightDate();
     return details;
 }
  
}
