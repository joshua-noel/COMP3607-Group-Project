// 816031467

import java.util.Scanner; 
import java.util.StringTokenizer;
import java.io.File;
import java.lang.String;

public class LuggageSlip
{
    private Passenger owner;
    private static int luggageSlipIDCounter = 1;
    private String luggageSlipID ;
    private String label;
    private Passenger p;
    private Flight f;
    private LuggageManifest lmf;
    
    //Constructor.
    public LuggageSlip (Passenger p, Flight f){
        this.p = p;
        this.f = f;
        this.label = null;
        this.owner = owner;
          this.luggageSlipID = this.f.getFightNo() + "_" + this.p.getLastName() +  "_" +this.luggageSlipIDCounter ++;
        this.luggageSlipIDCounter ++;
    }
    
    
    //overload Constructor.
    public LuggageSlip (Passenger p, Flight f, String label){
        this.p = p;
        this.f = f;
        this.label = label;
        this.owner = owner;
        this.luggageSlipID = this.f.getFightNo() + "_" + this.p.getLastName() +  "_" +this.luggageSlipIDCounter ++;
        this.luggageSlipIDCounter ++;
    }
    


    
    protected boolean hasOwner (String passportNumber){
        if (owner.getPassportNumber().equals(passportNumber)){
        //   luggageSlipIDCounter++;
        //   lmf.getExcessLuggageCostByPassenger(passportNumber);
           return true; 
        }
        else
            return false;
    }
    
   
    //public  lmf getLuggageManifestgExcessLuggageCostByPassenger() {
    //    return lmf;
   // }  
    
    public Passenger getOwner(){
        return owner;
    }
    
    public int getLuggageSlipIDCounter(){
        return luggageSlipIDCounter;
    }
    
    public String getLuggageSlipID(){
        return luggageSlipID;
    }
    
    public String getLabel(){
        return label;
    }
    
    
    public String toString(){
        String details = getLuggageSlipID()+ " "+ p.toString()+" "+ getLabel();
        return details;
    }
    
 
}
