
/** 816032289
 * Models a flight
 */
import java.time.LocalDateTime; /**Imports time object/class from java*/
import java.util.ArrayList; /**Imports ArrayList object/class from java*/

public class Flight
{
    /**Attributes*/
    private String flightNo;
    private String destination;
    private String origin;
    private LocalDateTime flightDate;
    private LuggageManifest manifest; 
    
    public Flight(String flightNo,String destination,String origin,LocalDateTime flightDate)
    {
        this.flightNo=flightNo;
        this.destination=destination;
        this.origin=origin;
        this.flightDate=flightDate;
        manifest= new LuggageManifest(); /**Initializes manifest*/
    }
    
    /**Accessors*/
    public String getflightNo(){
        return flightNo;
    }
    public String getdestination(){
        return destination;
    }
    public String getorigin(){
        return origin;
    }
    public LocalDateTime getflightDate(){
        return flightDate;
    }
    public LuggageManifest getmanifest(){
        return manifest;
    }
    
    /**Methods*/
    public String checkInLuggage(Passenger p){
        Flight f =new Flight(getflightNo(),getdestination(),getorigin(),getflightDate()); /**Gets curent flight*/
        ArrayList<Flight> flights= new ArrayList<Flight>(); 
        flights.add(f);
        String message="No luggage";
        for (Flight fl:flights){
            if(fl.getflightNo().equals(p.getflightNo())){ /**If flight exists or passenger flight matches existing flight*/
                for(int i=0;i<p.getnumLuggage();i++){ 
                    message=manifest.addLuggage(p,f); /**Add luggages*/
                }
            return message; /**Returns string from addLuggage method*/
            }
        }
        return "Invalid Flight Number"; /**returns if flight is not found*/
    }
    
    public int getAllowedLuggage (char cabinClass){ /**Returns the number of allowed luggages for the specified cabin class*/
        
        if (cabinClass=='F'){
            return 3; /**Allows 3 pieces of luggage*/
        }
        else if(cabinClass=='B'){
            return 2;
        }
        else if(cabinClass=='P'){
            return 1;
        }
        return 0;
    }
    
    public String toString(){  /**String output for class*/
        String message=getflightNo() 
        + " DESTINATION: " + getdestination()
        + " ORIGIN: " + getorigin()
        + " " + getflightDate();
        return message;
    }
    public String printLuggageManifest(){ /**Returns toString method for the luggageManifest class*/
        String message= getmanifest().toString();
        return message;
    }
}
