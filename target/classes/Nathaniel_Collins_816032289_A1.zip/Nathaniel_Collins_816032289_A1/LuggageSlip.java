
/**
 * models a paper slip that is generated for a piece of luggage when it is checked into a flight for a given passenger
 * 816032289
 */
public class LuggageSlip
{
    private Passenger owner;
    private static int luggageSlipIDCounter;
    private String luggageSlipID;
    private String label;
    
    public LuggageSlip(Passenger p,Flight f)
    {
        owner=p;
        luggageSlipIDCounter=incrementluggageSlipIDCounter();
        luggageSlipID=f.getflightNo()+"_"+owner.getlastName()+"_"+getluggageSlipIDCounter();
        label="";
    }
    public LuggageSlip(Passenger p, Flight f, String label)
    {
        owner=p;
        luggageSlipIDCounter=incrementluggageSlipIDCounter();
        luggageSlipID=owner.getflightNo()+"_"+owner.getlastName()+"_"+getluggageSlipIDCounter();
        this.label=label;
    }
    /**Accessors**/
    public String getlabel(){
        return label;
    }
    public Passenger getowner(){
        return owner;
    }
    public String getluggageSlipID(){
        return luggageSlipID;
    }
    public int getluggageSlipIDCounter(){
        return luggageSlipIDCounter;
    }
    /**Mutators*/
    public int incrementluggageSlipIDCounter(){ 
        /**incrementets the luggage Slip ID Counter**/
        luggageSlipIDCounter+=1;
        return luggageSlipIDCounter;
    }
    
    /**Methods*/
    public boolean hasOwner(String passportNumber){ /**Searches for owner of a passport**/
        if (owner.getpassportNumber().equals(passportNumber)){
            return true;
        }
        return false;
    }
    public String toString(){ /**Returns string output for class**/
        String message=getluggageSlipID() 
        +" PP NO: "+ owner.getpassportNumber()
        +" NAME: " + owner.getfirstName()
        +"."+owner.getlastName()
        +" NUMLUGGAGE: " +owner.getnumLuggage()
        +" CLASS " + owner.getcabinClass()
        +" " +getlabel();
        
        return message;
    }
    
}
