
/**
* manages one or more LuggageSlip objects within a slips collection.
* 816032289
*/

import java.util.ArrayList;

public class LuggageManifest
{
    private ArrayList<LuggageSlip> slips; /**Declares slips as an ArrayList of type LuggageSlip*/
    public LuggageManifest()
    {
        slips= new ArrayList<LuggageSlip>(); /**Initializes slips*/
    }
    /**Accessor*/
    public ArrayList<LuggageSlip> getslips(){
        return slips; /**returns ArrayList*/ 
    }
    
    /**Mehtods*/
    
    public String addLuggage(Passenger p, Flight f){ /**Adds luggage*/
        LuggageSlip slip;
        int excess=p.getnumLuggage()-f.getAllowedLuggage(p.getcabinClass()); /**Calculates the excess luggage*/
        
        /**Calculates the excess luggage cost*/
        Double luggageCost=getExcessLuggageCost(p.getnumLuggage(),f.getAllowedLuggage(p.getcabinClass())); 
        
        String message;
        if(p.getnumLuggage()<=f.getAllowedLuggage(p.getcabinClass())){ /**If the number of luggage is less than allowed*/
            excess=0; /**There is no excess luggage*/
            slip=new LuggageSlip(p,f); /**creates slip*/
            slips.add(slip); /**Adds slip to array list*/
            message=slip.getowner().getnumLuggage()+
            " pieces of luggage, "+ excess +" of excess"+"\nNo excess luggage";
        }else{
            slip=new LuggageSlip(p,f,luggageCost.toString()); /**There is excess. Excess cost is passed as the label*/
            slips.add(slip);
            message=slip.getowner().getnumLuggage()+
            " pieces of luggage "+ excess +" of excess"+"\nPieces added("+excess+")."+" Excess Cost: $"+luggageCost;
        }
        return message; /**Returns message*/
        
    }
    public double getExcessLuggageCost(int numPieces,int numAllowedPieces){ /**Calculates excess cost*/
        int excess= numPieces-numAllowedPieces;
        double cost=35.00*excess;
        return cost;
    }
    
    public String getExcessLuggageCostByPassenger(String passportNumber){ /**Searches for excess cost by passport number*/
        /**Loops through slips*/
        for(LuggageSlip m: getslips()){ 
            /**if passenger is found and excess cost is not empty*/
            if(m.getowner().getpassportNumber().equals(passportNumber) && m.getlabel()!=""){ 
                return "Excess Cost "+m.getlabel()
                +" by Passenger "+m.getowner().getfirstName()+" "+m.getowner().getlastName()+
                " PP.NO: "+m.getowner().getpassportNumber(); /**Returns string*/
            }
        }
        return "No Cost";
    }
    
    public String toString(){ /**returns String output for class */
        int i=0;
        String message="";
        String aggrMessage=""; /**Aggregated message*/
        /**Loops through all the slips*/
        for(i=0;i<slips.size();i++){
            message=slips.get(i).getluggageSlipID()+" "
            +"PP NO. "+slips.get(i).getowner().getpassportNumber()
            +" NAME: "+slips.get(i).getowner().getfirstName()+" "+slips.get(i).getowner().getlastName()
            +" NUMLUGGAGE "+ slips.get(i).getowner().getnumLuggage()
            +" CLASS: "+ slips.get(i).getowner().getcabinClass()+" "+slips.get(i).getlabel();
            aggrMessage=aggrMessage+"\n"+message; /**Appends message to aggregated message*/
        }
        return aggrMessage;
    }
}
