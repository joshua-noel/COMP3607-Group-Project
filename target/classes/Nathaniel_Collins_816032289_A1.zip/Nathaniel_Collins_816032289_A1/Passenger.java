
/**
 * Checks zero or more pieces of luggage into a flight
 * 816032289
 */

import java.util.Random; /**imports Random object/class from java*/

public class Passenger /**Passenger Class*/
{
    private String passportNumber;
    private String firstName;
    private String lastName;
    private String flightNo;
    private int numLuggage;
    private char cabinClass;

    public Passenger (String passportNumber,String firstName, String lastName, String flightNo){
        this.passportNumber=passportNumber;
        this.firstName=firstName;
        this.lastName=lastName;
        this.flightNo=flightNo;
        assignRandomCabinClass(); /**randomly generates a Cabin Class*/
        assignRandomNumLuggage(); /**Randomly generates the number of luggages for a passenger*/
    }
    /**Accessors*/
    public String getpassportNumber(){
        return passportNumber;
    }
    public String getflightNo(){
        return flightNo;
    }
    public String getfirstName(){
        return firstName;
    }
    public String getlastName(){
        return lastName;
    }
    public int getnumLuggage(){
        return numLuggage;
    }
    public char getcabinClass(){
        return cabinClass;
    }
    
    
    public void assignRandomCabinClass(){
        Random r= new Random(); /**initializes random*/
        char[] cClass= new char[4]; 
        
        /**Cabin class characters*/
        cClass[0]='F';
        cClass[1]='B';
        cClass[2]='P';
        cClass[3]='E';
        cabinClass=cClass[r.nextInt(4)]; /**assigns cabinClass variable*/
        
    }public void assignRandomNumLuggage(){
        Random r= new Random();
        numLuggage=r.nextInt(4); /**Assigns random number of luggage*/
    }
    
    public String toString(){ /**Returns a string message for class*/
        String message;
        message="PP NO."+getpassportNumber() /**Uses Accessors*/
        + " NAME: "+getfirstName() + " " + getlastName()
        + " NUMLUGGAGE: " + getnumLuggage()
        + " CLASS " + getcabinClass();
        return message;
    }
    
}
