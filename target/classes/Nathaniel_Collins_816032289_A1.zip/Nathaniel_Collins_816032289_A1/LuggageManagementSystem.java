
/**816032289
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LuggageManagementSystem
{
    
   
   public static void main (String[] args){
       ArrayList<Flight> flights= new ArrayList<Flight>();
       Passenger p=null;
       Flight yyz=null;
       /**read passenger and flight files here*/
       LocalDateTime d = LocalDateTime.of(2023,1,23,10,00,00);
       try{
           File flightsFile= new File("Flights.txt");
           Scanner flightsRead= new Scanner(flightsFile);
           String readData="";
           while(flightsRead.hasNextLine()){
              readData=flightsRead.nextLine(); /**gets line from file**/
              String[] sentence=new String[4]; 
              sentence=readData.split(",");
              yyz= new Flight(sentence[0],sentence[1],sentence[2],d);
              flights.add(yyz); /**Adds flight**/
           }
           flightsRead.close();
       }catch(Exception e){
           System.out.println("File Error");
           e.printStackTrace();
       }
       for(Flight f: flights){
           System.out.println(f.toString()); /**Prints String output for flight**/
       }
       try{
           File passengerFile= new File("Passenger.txt"); 
           Scanner passengerRead= new Scanner(passengerFile);
           String readData="";
           while(passengerRead.hasNextLine()){ /**Reads passenger file**/
              readData=passengerRead.nextLine();
              String[] sentence=new String[4];
              sentence=readData.split(",");
              p= new Passenger(sentence[0],sentence[1],sentence[2],sentence[3]); /**Creates passenger objeg**/
              System.out.println(p);/**Prints passenger opject**/
              System.out.println(yyz.checkInLuggage(p)); /**Calls and outputs checkInLuggage method**/
           }
           passengerRead.close(); /**Closes passenger file**/
       }catch(Exception e){
           System.out.println("File Error"); /**Prints error**/
           e.printStackTrace();
       }
       System.out.println("\nLUGGAGE MANIFEST");
       System.out.println(yyz.printLuggageManifest( )); /**Prints luggage Manifest**/
       LuggageManifest mani=yyz.getmanifest();
       System.out.println(mani.getExcessLuggageCostByPassenger("RA445241")); /**tests other methods**/
       
       //ArrayList<LuggageSlip> slip=mani.getslips();
       //System.out.println(slip.get(0).hasOwner("RA445241"));
   }
}
